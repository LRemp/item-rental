export default function Settings() {
  return (
    <div>
      <div>Settings</div>
    </div>
  );
}
