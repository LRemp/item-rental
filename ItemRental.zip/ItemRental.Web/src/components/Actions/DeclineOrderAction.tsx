import { Text } from '@mantine/core';
import { modals } from '@mantine/modals';
import { notifications } from '@mantine/notifications';
import { useCallback } from 'react';
import { Error, Success } from '@/utils/Notifications';
import useApiResult from '@/hooks/useApiResult';
import api from '@/api';

const useDeclineOrderAction = () => {
  const { request } = useApiResult(api.Order.decline);

  const declineOrder = useCallback((id: string) => {
    modals.openConfirmModal({
      centered: true,
      title: 'Decline this order request?',
      children: (
        <Text size="sm">
          Are you sure to decline this order? The order status will be changes to Declined and will
          cancel the order proccess.
        </Text>
      ),
      labels: { confirm: 'Decline', cancel: 'Cancel' },
      confirmProps: { color: 'red' },
      onConfirm: async () => {
        const notificationId = notifications.show({
          loading: true,
          title: 'Loading',
          message: 'Accepting order...',
          autoClose: false,
          withCloseButton: false,
        });

        try {
          await request(id);
          notifications.update(
            Success({
              id: notificationId,
              title: 'Success',
              message: 'The order was successfuly confirmed!',
            })
          );
        } catch (e: any) {
          notifications.update(
            Error({
              id: notificationId,
              title: 'Error',
              message: e.message,
            })
          );
        }
      },
    });
  }, []);

  return declineOrder;
};

export default useDeclineOrderAction;
