import React from 'react';

function CategoriesList() {
  return <div>CategoriesList</div>;
}

export default CategoriesList;
