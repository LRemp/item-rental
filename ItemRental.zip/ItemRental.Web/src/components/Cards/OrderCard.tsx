import React from 'react';

function OrderCard() {
  return <div>OrderCard</div>;
}

export default OrderCard;
