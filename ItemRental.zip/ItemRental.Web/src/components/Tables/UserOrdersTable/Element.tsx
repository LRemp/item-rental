import React from 'react';

function Element() {
  return <div>Element</div>;
}

export default Element;
