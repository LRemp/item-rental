type NotificationProps = {
  id?: string;
  title: string;
  message: string;
  autoClose?: number;
};
