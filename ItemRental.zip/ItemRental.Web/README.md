# Inventory rental app front-end
