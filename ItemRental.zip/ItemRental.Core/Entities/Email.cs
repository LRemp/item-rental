﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemRental.Core.Entities
{
    public class Email
    {
        public string Address = string.Empty;
        public string Subject = string.Empty;
        public string PlainTextContent = string.Empty;
        public string HTMLcontent = string.Empty;
    }
}
