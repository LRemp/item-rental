﻿using Dapper;
using ItemRental.Core.Entities;
using ItemRental.Repositories.Repositories;
using ItemRental.Services.Services;
using Moq;
using MySqlConnector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ItemRental.Tests.Repositories
{
    public class DeliveryRepositoryTests
    {
        [Fact]
        public async Task AddAsync_WhenCalled_ReturnsTrue()
        {
            
        }
    }
}
